package com.example.app_pertamaku

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
